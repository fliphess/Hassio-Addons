"""The DSMR Reader component."""
